#!/bin/bash
# 啟動腳本
cd "$(dirname "$0")"
./淨膚寶薪資計算程式
